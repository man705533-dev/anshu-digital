/* सार्वजनिक वेबसाइट सेटिंग्स। केवल Supabase URL और publishable/anon key यहाँ रखें.
   OpenAI API key जैसे SECRET कभी इस फाइल में न डालें। */
window.ANSHU_CONFIG = {
  supabaseUrl: "",             // उदाहरण: https://YOUR-PROJECT.supabase.co
  supabaseAnonKey: "",         // Supabase publishable/anon key
  whatsappNumber: "",          // देश कोड सहित केवल अंक, उदाहरण: 919876543210
  contactEmail: "",            // उदाहरण: hello@example.com
  socials: {
    instagram: "https://www.instagram.com/",
    youtube: "https://www.youtube.com/",
    facebook: "https://www.facebook.com/",
    other: "https://www.linkedin.com/"
  },
  aiEndpoint: "/.netlify/functions/chat"
};
