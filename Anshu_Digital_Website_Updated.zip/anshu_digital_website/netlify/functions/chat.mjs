const json = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  },
  body: JSON.stringify(body)
});

export async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, OPTIONS" }, body: "" };
  }
  if (event.httpMethod !== "POST") return json(405, { error: "केवल POST अनुरोध स्वीकार हैं।" });
  if (!process.env.OPENAI_API_KEY) return json(503, { error: "AI अभी सेटअप नहीं है। Netlify में OPENAI_API_KEY environment variable जोड़ें।" });

  let payload;
  try { payload = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "संदेश पढ़ा नहीं जा सका।" }); }
  const messages = Array.isArray(payload.messages) ? payload.messages : [];
  const safeMessages = messages.slice(-12).filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string").map(m => ({ role: m.role, content: m.content.slice(0, 2000) }));
  if (!safeMessages.length || !safeMessages.some(m => m.role === "user")) return json(400, { error: "पहले अपना सवाल लिखें।" });
  if (safeMessages.reduce((n, m) => n + m.content.length, 0) > 12000) return json(413, { error: "यह बातचीत बहुत लंबी है। नई चैट शुरू करें।" });

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "You are Anshu AI, a helpful general-purpose assistant on a personal website. Reply in the language used by the user (Hindi by default). Be accurate, age-appropriate, and do not claim to be ChatGPT or OpenAI. If unsure, say so. Do not ask for passwords, API keys, or private personal information.",
        input: safeMessages.map(m => ({ role: m.role, content: m.content })),
        max_output_tokens: 700
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const status = upstream.status === 429 ? 429 : 502;
      return json(status, { error: upstream.status === 429 ? "AI सेवा की सीमा पूरी हो गई है। थोड़ी देर बाद कोशिश करें।" : "AI सेवा से जवाब नहीं मिला। API सेटिंग जाँचें।" });
    }
    const answer = (result.output || []).flatMap(item => item.content || []).find(item => item.type === "output_text")?.text?.trim();
    if (!answer) return json(502, { error: "AI से खाली जवाब मिला। फिर से कोशिश करें।" });
    return json(200, { answer });
  } catch {
    return json(502, { error: "नेटवर्क समस्या हुई। थोड़ी देर बाद फिर कोशिश करें।" });
  }
}
