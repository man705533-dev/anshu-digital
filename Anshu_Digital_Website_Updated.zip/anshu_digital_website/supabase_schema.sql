-- Anshu Digital — Supabase setup
-- Supabase Dashboard > SQL Editor में यह पूरा SQL चलाएँ.
-- Admin बनाने के लिए नीचे वाले UPDATE में अपना account email भरें; इसे किसी और को न दें.

create extension if not exists pgcrypto;

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  body text not null default '',
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  media_url text not null,
  kind text not null check (kind in ('photo','video')),
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.downloads (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  file_url text not null,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.posts enable row level security;
alter table public.gallery_items enable row level security;
alter table public.downloads enable row level security;

-- Public visitors can read published content; only admin can read drafts or change content.
drop policy if exists "read published posts" on public.posts;
create policy "read published posts" on public.posts for select to anon, authenticated
using (published = true or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin insert posts" on public.posts;
create policy "admin insert posts" on public.posts for insert to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin update posts" on public.posts;
create policy "admin update posts" on public.posts for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin delete posts" on public.posts;
create policy "admin delete posts" on public.posts for delete to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "read published gallery" on public.gallery_items;
create policy "read published gallery" on public.gallery_items for select to anon, authenticated
using (published = true or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin insert gallery" on public.gallery_items;
create policy "admin insert gallery" on public.gallery_items for insert to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin update gallery" on public.gallery_items;
create policy "admin update gallery" on public.gallery_items for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin delete gallery" on public.gallery_items;
create policy "admin delete gallery" on public.gallery_items for delete to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "read published downloads" on public.downloads;
create policy "read published downloads" on public.downloads for select to anon, authenticated
using (published = true or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin insert downloads" on public.downloads;
create policy "admin insert downloads" on public.downloads for insert to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin update downloads" on public.downloads;
create policy "admin update downloads" on public.downloads for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin delete downloads" on public.downloads;
create policy "admin delete downloads" on public.downloads for delete to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Public media bucket. Read access is public; upload/update/delete requires admin role.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 52428800, array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','application/pdf','text/plain']::text[])
on conflict (id) do update set public = true;

drop policy if exists "public read media" on storage.objects;
create policy "public read media" on storage.objects for select to anon, authenticated using (bucket_id = 'media');
drop policy if exists "admin upload media" on storage.objects;
create policy "admin upload media" on storage.objects for insert to authenticated with check (bucket_id = 'media' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin update media" on storage.objects;
create policy "admin update media" on storage.objects for update to authenticated using (bucket_id = 'media' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check (bucket_id = 'media' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admin delete media" on storage.objects;
create policy "admin delete media" on storage.objects for delete to authenticated using (bucket_id = 'media' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Run only after you create your own account and replace the email below:
-- UPDATE auth.users
-- SET raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
-- WHERE email = 'YOUR-LOGIN-EMAIL@example.com';
-- Sign out and sign back in after assigning the role so the new JWT includes app_metadata.role.
