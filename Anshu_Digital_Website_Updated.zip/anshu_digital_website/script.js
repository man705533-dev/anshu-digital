'use strict';

const CONFIG = window.ANSHU_CONFIG || {};
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const hasSupabaseConfig = Boolean(CONFIG.supabaseUrl && CONFIG.supabaseAnonKey);
let db = null;
let currentUser = null;
let adminMode = false;
let authMode = 'login';
let currentLanguage = 'hi';
let chatHistory = [];
let chatBusy = false;

if (hasSupabaseConfig && window.supabase?.createClient) {
  db = window.supabase.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey);
}

const translations = {
  en: {
    navHome:'Home',navAbout:'About',navGallery:'Gallery',navBlog:'Blog / News',navDownloads:'Downloads',navContact:'Contact',login:'Login / Sign up',adminPanel:'Admin panel',
    eyebrow:'Your digital identity',heroTitle:'Hello, welcome to<br><span>Anshu Digital</span>',heroText:'Welcome to my digital world. Explore posts, photos, videos, helpful files and an AI assistant.',explore:'Explore website',askAI:'Ask AI',heroNote:'Hindi • English • Mobile friendly',searchPlaceholder:'Search posts, photos and downloads…',clear:'Clear',aboutEyebrow:'About',aboutTitle:'About me',aboutHeading:'This is my digital space.',aboutText:'Add your introduction, interests, work, achievements and useful links here. Replace this starter text with your own details.',chip1:'My interests',chip2:'My goals',chip3:'My identity',galleryEyebrow:'Moments & memories',galleryTitle:'Photo & video gallery',galleryText:'Sample content is shown. Add your own media using the admin panel.',all:'All',photos:'Photos',videos:'Videos',blogTitle:'Blog and news',blogText:'New posts and updates will appear here. These are starter examples.',downloadsTitle:'Downloads',downloadsText:'Helpful files and documents. Add your own links from the admin panel.',aiTitle:'Your AI assistant',aiText:'Ask questions, explore a topic or get help with ideas. Server-side API setup is required for real AI responses.',aiReady:'Assistant interface',chatPlaceholder:'Type your question…',socialTitle:'Social media',socialText:'Edit the links below in config.js to point to your profiles.',contactTitle:'Let’s talk.',contactText:'Questions, suggestions or collaboration? Reach out by email or WhatsApp.',footerText:'Your digital world, in one place'
  }
};

function setLanguage(lang) {
  currentLanguage = lang;
  document.documentElement.lang = lang === 'hi' ? 'hi' : 'en';
  $$('#langToggle').forEach(button => button.textContent = lang === 'hi' ? 'EN' : 'हि');
  const dict = translations[lang] || {};
  $$('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (lang === 'en' && dict[key]) el.innerHTML = dict[key];
    else if (lang === 'hi') el.innerHTML = el.dataset.hi || el.getAttribute('data-default-text') || originalHindi[key] || el.innerHTML;
  });
  $$('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    if (lang === 'en' && dict[key]) el.placeholder = dict[key];
    if (lang === 'hi') el.placeholder = originalPlaceholders[key] || el.placeholder;
  });
}

// Keep the original Hindi copy so language toggling always returns cleanly.
const originalHindi = {};
const originalPlaceholders = {};
$$('[data-i18n]').forEach(el => { originalHindi[el.dataset.i18n] = el.innerHTML; });
$$('[data-i18n-placeholder]').forEach(el => { originalPlaceholders[el.dataset.i18nPlaceholder] = el.placeholder; });

// Mobile navigation.
const menuToggle = $('#menuToggle');
const navLinks = $('#navLinks');
menuToggle?.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
$$('#navLinks a').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));
$('#year').textContent = new Date().getFullYear();
$('#langToggle')?.addEventListener('click', () => setLanguage(currentLanguage === 'hi' ? 'en' : 'hi'));

// Contact and social links are safely customized in config.js.
function setupLinks() {
  const email = String(CONFIG.contactEmail || '').trim();
  const phone = String(CONFIG.whatsappNumber || '').replace(/\D/g, '');
  $('#contactEmailText').textContent = email || 'yourname@example.com';
  $('#emailButton').href = email ? `mailto:${email}` : 'mailto:yourname@example.com';
  $('#contactPhoneText').textContent = phone || 'नंबर सेट नहीं है';
  $('#whatsappButton').href = phone ? `https://wa.me/${phone}` : 'https://wa.me/';
  for (const [key, id] of [['instagram','instagramLink'],['youtube','youtubeLink'],['facebook','facebookLink'],['other','otherSocialLink']]) {
    const url = CONFIG.socials?.[key];
    if (url && /^https:\/\//i.test(url)) $(`#${id}`).href = url;
  }
}
setupLinks();

// Content search covers articles, media and downloads on the page.
const searchInput = $('#siteSearch');
function runSearch() {
  const term = (searchInput.value || '').trim().toLocaleLowerCase();
  let visible = 0;
  $$('.searchable').forEach(item => {
    const found = !term || `${item.textContent} ${item.dataset.search || ''}`.toLocaleLowerCase().includes(term);
    const galleryAllowed = !item.dataset.kind || item.dataset.kind === 'all' || item.dataset.kind === ($('#galleryGrid').dataset.filter || 'all') || ($('#galleryGrid').dataset.filter || 'all') === 'all';
    item.hidden = !(found && galleryAllowed);
    if (found && galleryAllowed) visible++;
  });
  $('#searchStatus').textContent = term ? (currentLanguage === 'hi' ? `मिलते-जुलते परिणाम: ${visible}` : `Matching results: ${visible}`) : '';
  $('#postsEmpty').hidden = !term || $$('#postsGrid .searchable:not([hidden])').length > 0;
  $('#downloadsEmpty').hidden = !term || $$('#downloadsList .searchable:not([hidden])').length > 0;
  $('#galleryEmpty').hidden = $$('#galleryGrid .photo:not([hidden])').length > 0;
}
searchInput.addEventListener('input', runSearch);
$('#clearSearch').addEventListener('click', () => { searchInput.value = ''; runSearch(); searchInput.focus(); });
$$('.filter-button').forEach(button => button.addEventListener('click', () => {
  $$('.filter-button').forEach(b => b.classList.toggle('active', b === button));
  $('#galleryGrid').dataset.filter = button.dataset.filter;
  runSearch();
}));

// Supabase setup enables real email/password accounts, persistent content and a secured admin role.
const loginDialog = $('#loginDialog');
$('#openLogin').addEventListener('click', () => loginDialog.showModal());
$('#closeLogin').addEventListener('click', () => loginDialog.close());
loginDialog.addEventListener('click', event => { if (event.target === loginDialog) loginDialog.close(); });
function setAuthMode(mode) {
  authMode = mode;
  $$('.auth-tab').forEach(tab => tab.classList.toggle('active', tab.dataset.authMode === mode));
  $('#authTitle').textContent = mode === 'login' ? 'लॉगिन करें' : 'नया अकाउंट बनाएँ';
  $('#authName').hidden = mode !== 'signup';
  $('#authNameLabel').hidden = mode !== 'signup';
  $('#authName').required = mode === 'signup';
  $('#authSubmit').textContent = mode === 'login' ? 'लॉगिन करें' : 'साइनअप करें';
  $('#resetPassword').hidden = mode !== 'login' || Boolean(currentUser);
  $('#authMessage').textContent = '';
}
$$('.auth-tab').forEach(tab => tab.addEventListener('click', () => setAuthMode(tab.dataset.authMode)));

function setAuthMessage(message, isError = false) {
  const el = $('#authMessage');
  el.textContent = message;
  el.style.color = isError ? '#fda4af' : 'var(--cyan)';
}
function updateAuthUI(user) {
  currentUser = user || null;
  adminMode = currentUser?.app_metadata?.role === 'admin';
  $('#adminNav').hidden = !adminMode;
  $('#admin').hidden = !adminMode;
  $('#logoutButton').hidden = !currentUser;
  $('#authForm').querySelectorAll('input, #authSubmit').forEach(el => el.hidden = Boolean(currentUser));
  $('#resetPassword').hidden = Boolean(currentUser) || authMode !== 'login';
  $('#authInfo').textContent = currentUser
    ? `लॉगिन है: ${currentUser.email || 'आपका अकाउंट'}${adminMode ? ' — Admin access' : ''}`
    : hasSupabaseConfig
      ? 'अपने ईमेल से लॉगिन करें या नया अकाउंट बनाएँ।'
      : 'असली अकाउंट चालू करने के लिए config.js और Supabase SQL सेटअप पूरा करें।';
  if (currentUser) $('#authTitle').textContent = adminMode ? 'आप लॉगिन हैं — Admin' : 'आप लॉगिन हैं';
  else setAuthMode(authMode);
}

$('#authForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!db) {
    setAuthMessage('पहले config.js में Supabase URL और anon key सेट करें, फिर Supabase SQL चलाएँ।', true);
    return;
  }
  const email = $('#authEmail').value.trim();
  const password = $('#authPassword').value;
  $('#authSubmit').disabled = true;
  setAuthMessage('कृपया प्रतीक्षा करें…');
  try {
    let result;
    if (authMode === 'signup') {
      result = await db.auth.signUp({ email, password, options: { data: { full_name: $('#authName').value.trim() } } });
      if (result.error) throw result.error;
      setAuthMessage(result.data.session ? 'अकाउंट बन गया और लॉगिन हो गया।' : 'अकाउंट बनाया गया। ईमेल में confirmation link चेक करें।');
    } else {
      result = await db.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      setAuthMessage('लॉगिन सफल।');
      updateAuthUI(result.data.user);
      await refreshAuthAndContent(result.data.user);
    }
  } catch (error) {
    setAuthMessage(error?.message || 'प्रक्रिया पूरी नहीं हुई। सेटिंग जाँचें।', true);
  } finally {
    $('#authSubmit').disabled = false;
  }
});
$('#resetPassword').addEventListener('click', async () => {
  if (!db) return setAuthMessage('पहले Supabase सेटअप पूरा करें।', true);
  const email = $('#authEmail').value.trim();
  if (!email) return setAuthMessage('पहले अपना ईमेल लिखें।', true);
  try {
    const { error } = await db.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
    if (error) throw error;
    setAuthMessage('पासवर्ड रीसेट लिंक ईमेल कर दिया गया है।');
  } catch (error) { setAuthMessage(error.message || 'रीसेट लिंक नहीं भेजा गया।', true); }
});
$('#logoutButton').addEventListener('click', async () => {
  if (!db) return;
  const { error } = await db.auth.signOut();
  if (error) return setAuthMessage(error.message, true);
  updateAuthUI(null);
  setAuthMessage('आप लॉगआउट हो गए हैं।');
  loginDialog.close();
});

function setAdminMessage(message, isError = false) {
  $('#adminMessage').textContent = message;
  $('#adminMessage').style.color = isError ? '#fda4af' : 'var(--cyan)';
}
function renderPosts(items) {
  if (!items?.length) return;
  const grid = $('#postsGrid');
  grid.innerHTML = items.map((item, i) => `<article class="content-card searchable" data-search="${escapeHTML(`${item.title} ${item.description} ${item.body}`)}" data-record-id="${escapeHTML(item.id)}" data-record-table="posts"><div class="content-icon">✦</div><p class="card-kicker">${escapeHTML(new Date(item.created_at || Date.now()).toLocaleDateString(currentLanguage === 'hi' ? 'hi-IN' : 'en-IN'))}</p><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.description || item.body || '')}</p>${item.body ? `<details><summary>पूरा लेख पढ़ें</summary><p>${escapeHTML(item.body)}</p></details>` : ''}<span class="card-tag">ब्लॉग / न्यूज़</span>${adminMode ? `<button class="delete-content" data-delete-id="${escapeHTML(item.id)}" data-delete-table="posts" type="button">हटाएँ</button>` : ''}</article>`).join('');
}
function renderGallery(items) {
  if (!items?.length) return;
  const grid = $('#galleryGrid');
  grid.querySelectorAll('[data-record-table="gallery_items"]').forEach(el => el.remove());
  items.forEach(item => {
    const kind = item.kind === 'video' ? 'video' : 'photo';
    const media = kind === 'photo'
      ? `<img src="${escapeHTML(item.media_url)}" alt="${escapeHTML(item.title)}" loading="lazy">`
      : `<a href="${escapeHTML(item.media_url)}" target="_blank" rel="noopener noreferrer" aria-label="वीडियो खोलें"><div class="video-placeholder"><span>▶</span><small>VIDEO</small></div></a>`;
    const figure = document.createElement('figure');
    figure.className = `photo searchable ${kind === 'photo' ? '' : 'video-card'}`;
    figure.dataset.kind = kind;
    figure.dataset.search = `${item.title} ${item.description || ''} ${kind}`;
    figure.dataset.recordId = item.id;
    figure.dataset.recordTable = 'gallery_items';
    figure.innerHTML = `${media}<figcaption><b>${escapeHTML(item.title)}</b><span>${escapeHTML(item.description || '')}</span>${adminMode ? `<button class="delete-content" data-delete-id="${escapeHTML(item.id)}" data-delete-table="gallery_items" type="button">हटाएँ</button>` : ''}</figcaption>`;
    grid.appendChild(figure);
  });
}
function renderDownloads(items) {
  if (!items?.length) return;
  const list = $('#downloadsList');
  list.querySelectorAll('[data-record-table="downloads"]').forEach(el => el.remove());
  items.forEach(item => {
    const row = document.createElement('article');
    row.className = 'download-item searchable';
    row.dataset.search = `${item.title} ${item.description || ''}`;
    row.dataset.recordId = item.id;
    row.dataset.recordTable = 'downloads';
    row.innerHTML = `<div class="file-icon">FILE</div><div class="download-info"><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.description || '')}</p></div><a class="button secondary small-button" href="${escapeHTML(item.file_url)}" target="_blank" rel="noopener noreferrer">खोलें ↗</a>${adminMode ? `<button class="delete-content" data-delete-id="${escapeHTML(item.id)}" data-delete-table="downloads" type="button">हटाएँ</button>` : ''}`;
    list.appendChild(row);
  });
}
async function fetchPublishedContent() {
  if (!db) return;
  try {
    const [posts, gallery, downloads] = await Promise.all([
      db.from('posts').select('*').eq('published', true).order('created_at', { ascending: false }).limit(30),
      db.from('gallery_items').select('*').eq('published', true).order('created_at', { ascending: false }).limit(40),
      db.from('downloads').select('*').eq('published', true).order('created_at', { ascending: false }).limit(30)
    ]);
    if (!posts.error && posts.data?.length) renderPosts(posts.data);
    if (!gallery.error && gallery.data?.length) renderGallery(gallery.data);
    if (!downloads.error && downloads.data?.length) renderDownloads(downloads.data);
    runSearch();
  } catch (error) { console.warn('Content could not be refreshed:', error); }
}
async function loadAdminContent() {
  const list = $('#adminContentList');
  if (!db || !adminMode) { list.innerHTML = '<p class="muted">Supabase और admin role सेटअप करने के बाद सामग्री यहाँ आएगी।</p>'; return; }
  list.innerHTML = '<p class="muted">सामग्री लोड हो रही है…</p>';
  const all = [];
  for (const table of ['posts','gallery_items','downloads']) {
    const { data, error } = await db.from(table).select('id,title,created_at').order('created_at', { ascending: false }).limit(30);
    if (!error && data) data.forEach(item => all.push({ ...item, table }));
  }
  if (!all.length) { list.innerHTML = '<p class="muted">अभी प्रकाशित सामग्री नहीं है।</p>'; return; }
  list.innerHTML = all.sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).map(item => `<div class="admin-content-row"><div><b>${escapeHTML(item.title)}</b><small>${escapeHTML(item.table)} · ${escapeHTML(new Date(item.created_at).toLocaleDateString())}</small></div><button class="delete-content" data-delete-id="${escapeHTML(item.id)}" data-delete-table="${escapeHTML(item.table)}" type="button">हटाएँ</button></div>`).join('');
}
async function refreshAuthAndContent(user) {
  updateAuthUI(user);
  if (adminMode) await loadAdminContent();
  await fetchPublishedContent();
}
if (db) {
  db.auth.getSession().then(({ data }) => refreshAuthAndContent(data.session?.user || null));
  db.auth.onAuthStateChange((_event, session) => {
    const user = session?.user || null;
    updateAuthUI(user);
    setTimeout(() => refreshAuthAndContent(user), 0);
  });
} else {
  updateAuthUI(null);
  $('#aiStatus').textContent = 'AI फीचर चलाने के लिए Netlify पर OPENAI_API_KEY जोड़ें और साइट को functions सहित deploy करें।';
}

$('#adminContentForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!db || !adminMode) return setAdminMessage('सुरक्षित Admin अकाउंट और Supabase सेटअप जरूरी है।', true);
  const table = $('#contentType').value;
  const title = $('#contentTitle').value.trim();
  const description = $('#contentDescription').value.trim();
  const typedUrl = $('#contentUrl').value.trim();
  const file = $('#contentFile').files?.[0];
  if (typedUrl && !/^https:\/\//i.test(typedUrl)) return setAdminMessage('कृपया https:// से शुरू होने वाला URL दें।', true);
  if (file && file.size > 50 * 1024 * 1024) return setAdminMessage('फाइल 50 MB से बड़ी है। छोटी फाइल चुनें।', true);
  $('#adminContentForm button[type="submit"]').disabled = true;
  setAdminMessage('सामग्री सेव हो रही है…');
  try {
    let mediaUrl = typedUrl;
    if (file) {
      const allowed = ['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','application/pdf','text/plain'];
      if (!allowed.includes(file.type)) throw new Error('यह फाइल प्रकार अनुमति सूची में नहीं है।');
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-80);
      const path = `${Date.now()}-${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await db.storage.from('media').upload(path, file, { upsert: false, contentType: file.type });
      if (uploadError) throw uploadError;
      const { data: publicData } = db.storage.from('media').getPublicUrl(path);
      mediaUrl = publicData.publicUrl;
    }
    let record;
    if (table === 'posts') {
      record = { title, description, body: description, published: true };
    } else if (table === 'gallery_items') {
      if (!mediaUrl) throw new Error('गैलरी आइटम के लिए मीडिया URL या फाइल जरूरी है।');
      const fileType = file?.type || '';
      const kind = fileType.startsWith('video/') || /\.(mp4|webm)(\?|$)/i.test(mediaUrl) ? 'video' : 'photo';
      record = { title, description, media_url: mediaUrl, kind, published: true };
    } else {
      if (!mediaUrl) throw new Error('डाउनलोड के लिए URL या फाइल जरूरी है।');
      record = { title, description, file_url: mediaUrl, published: true };
    }
    const { error } = await db.from(table).insert(record);
    if (error) throw error;
    $('#adminContentForm').reset();
    setAdminMessage('सामग्री प्रकाशित हो गई।');
    await loadAdminContent();
    await fetchPublishedContent();
  } catch (error) {
    setAdminMessage(error.message || 'सामग्री सेव नहीं हुई। SQL policies और storage setup जाँचें।', true);
  } finally {
    $('#adminContentForm button[type="submit"]').disabled = false;
  }
});

// Delete actions remain guarded by Supabase row-level security.
document.addEventListener('click', async event => {
  const button = event.target.closest('[data-delete-id][data-delete-table]');
  if (!button) return;
  if (!db || !adminMode) return;
  if (!window.confirm('क्या आप इस सामग्री को हटाना चाहते हैं?')) return;
  button.disabled = true;
  const { error } = await db.from(button.dataset.deleteTable).delete().eq('id', button.dataset.deleteId);
  if (error) { window.alert(`हटाया नहीं जा सका: ${error.message}`); button.disabled = false; return; }
  await loadAdminContent();
  // Rebuild seeded content only by refreshing; user entries are fetched from database.
  window.location.reload();
});

// Chat UI. The API key lives only in the Netlify Function environment, never in the browser.
const chatMessages = $('#chatMessages');
function addBubble(text, role = 'assistant') {
  const bubble = document.createElement('div');
  bubble.className = `chat-bubble ${role === 'user' ? 'user-bubble' : 'assistant-bubble'}`;
  bubble.textContent = text;
  chatMessages.appendChild(bubble);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return bubble;
}
async function askAI(message) {
  if (chatBusy) return;
  const text = message.trim();
  if (!text) return;
  chatBusy = true;
  $('#chatInput').value = '';
  addBubble(text, 'user');
  chatHistory.push({ role: 'user', content: text });
  const typing = document.createElement('div'); typing.className = 'typing'; typing.textContent = 'Anshu AI जवाब लिख रहा है…'; chatMessages.appendChild(typing);
  $('#sendChat').disabled = true;
  try {
    const response = await fetch(CONFIG.aiEndpoint || '/.netlify/functions/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: chatHistory.slice(-12) })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'AI endpoint उपलब्ध नहीं है।');
    const answer = String(result.answer || '').trim() || 'मुझे कोई जवाब नहीं मिला।';
    chatHistory.push({ role: 'assistant', content: answer });
    addBubble(answer, 'assistant');
    $('#aiStatus').textContent = 'AI चैट सक्रिय है। जवाब की महत्वपूर्ण बातों की जाँच करें।';
  } catch (error) {
    const friendly = error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')
      ? 'AI अभी उपलब्ध नहीं है। इसे चालू करने के लिए Netlify Function और OPENAI_API_KEY सेट करें।'
      : error.message;
    addBubble(friendly, 'assistant');
    $('#aiStatus').textContent = 'AI सेटअप या कनेक्शन की जाँच जरूरी है।';
  } finally {
    typing.remove();
    chatBusy = false;
    $('#sendChat').disabled = false;
    $('#chatInput').focus();
  }
}
$('#chatForm').addEventListener('submit', event => { event.preventDefault(); askAI($('#chatInput').value); });
$$('.suggestion').forEach(button => button.addEventListener('click', () => askAI(button.dataset.prompt || button.textContent)));
$('#clearChat').addEventListener('click', () => {
  chatHistory = [];
  chatMessages.innerHTML = '';
  addBubble(currentLanguage === 'hi' ? 'नमस्ते! मुझसे हिंदी या English में पूछें।' : 'Hello! Ask me in Hindi or English.');
});
